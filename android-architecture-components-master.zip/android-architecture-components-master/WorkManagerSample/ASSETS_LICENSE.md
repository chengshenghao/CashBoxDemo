## Assets License

* `src/main/assets/images/lit_pier.jpg` courtesy [Romain Guy](https://www.flickr.com/photos/romainguy/) 
   under [CC-2](https://creativecommons.org/licenses/by/2.0/).
* `src/main/assets/images/parting_ways.jpg` courtesy [Romain Guy](https://www.flickr.com/photos/romainguy/)
   under [CC-2](https://creativecommons.org/licenses/by/2.0/).
* `src/main/assets/images/wrong_way.jpg` courtesy [Romain Guy](https://www.flickr.com/photos/romainguy/)
   under [CC-2](https://creativecommons.org/licenses/by/2.0/).
